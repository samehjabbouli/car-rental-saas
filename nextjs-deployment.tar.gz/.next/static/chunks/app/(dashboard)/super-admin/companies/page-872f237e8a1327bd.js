(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[172],{2864:function(e,t,a){Promise.resolve().then(a.bind(a,32891))},98998:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("AlertCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},61524:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("AlertTriangle",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",key:"c3ski4"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]])},80559:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("Building2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]])},46578:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]])},49108:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},37805:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},14960:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("ChevronsLeft",[["path",{d:"m11 17-5-5 5-5",key:"13zhaf"}],["path",{d:"m18 17-5-5 5-5",key:"h8a8et"}]])},98306:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("ChevronsRight",[["path",{d:"m6 17 5-5-5-5",key:"xnjwq"}],["path",{d:"m13 17 5-5-5-5",key:"17xmmf"}]])},37841:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},28814:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]])},70094:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},29295:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("SquarePen",[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4Z",key:"1lpok0"}]])},52235:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(87461).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},32891:function(e,t,a){"use strict";a.r(t),a.d(t,{CompaniesManagement:function(){return k}});var n=a(3827),s=a(64090),r=a(8792),i=a(51097),c=a(5887),l=a(575),d=a(15671),u=a(40326),h=a(80559),o=a(37841),p=a(29295),m=a(87461);/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let f=(0,m.Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);var x=a(70094);/**
 * @license lucide-react v0.314.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let y=(0,m.Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);function k(){let e=(0,i.e)(),{addToast:t}=(0,u.useToast)(),[a,m]=(0,s.useState)([]),[k,j]=(0,s.useState)(!0),[g,v]=(0,s.useState)(1),[Z,b]=(0,s.useState)(0),[N,M]=(0,s.useState)(""),[w,z]=(0,s.useState)(""),[C,S]=(0,s.useState)(!1);(0,s.useEffect)(()=>{_()},[g,N,w]);let _=async()=>{j(!0);try{let t=e.from("companies").select("*",{count:"exact"}).order("created_at",{ascending:!1}).range((g-1)*10,10*g-1);w&&(t=t.eq("status",w)),N&&(t=t.or("name.ilike.%".concat(N,"%,email.ilike.%").concat(N,"%")));let{data:a,count:n,error:s}=await t;if(s)throw s;m(a||[]),b(n||0)}catch(e){console.error("Error:",e),t({type:"error",title:"خطأ في تحميل الشركات"})}finally{j(!1)}},q=async a=>{if(confirm("هل أنت متأكد من حذف هذه الشركة؟"))try{let{error:n}=await e.from("companies").delete().eq("id",a);if(n)throw n;t({type:"success",title:"تم حذف الشركة بنجاح"}),_()}catch(e){t({type:"error",title:"حدث خطأ أثناء الحذف"})}},E=[{key:"name",label:"اسم الشركة",sortable:!0,render:(e,t)=>(0,n.jsxs)("div",{className:"flex items-center gap-3",children:[(0,n.jsx)("div",{className:"flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10",children:(0,n.jsx)(h.Z,{className:"h-5 w-5 text-primary"})}),(0,n.jsxs)("div",{children:[(0,n.jsx)("p",{className:"font-medium",children:String(e||"-")}),t.commercial_name&&(0,n.jsx)("p",{className:"text-xs text-muted-foreground",children:t.commercial_name})]})]})},{key:"email",label:"البريد الإلكتروني"},{key:"phone",label:"الهاتف"},{key:"status",label:"الحالة",render:e=>(0,n.jsx)(c.OE,{status:e})},{key:"subscription_plan",label:"الباقة",render:e=>(0,n.jsx)("span",{className:"capitalize",children:e||"-"})},{key:"max_vehicles",label:"السيارات",align:"center"},{key:"created_at",label:"تاريخ التسجيل",render:e=>new Date(e).toLocaleDateString("ar-SA")},{key:"actions",label:"الإجراءات",align:"center",render:(e,t)=>(0,n.jsxs)("div",{className:"flex items-center gap-1 justify-center",children:[(0,n.jsx)(r.default,{href:"/super-admin/companies/".concat(t.id),children:(0,n.jsx)(l.z,{variant:"ghost",size:"sm",children:(0,n.jsx)(o.Z,{className:"h-4 w-4"})})}),(0,n.jsx)(r.default,{href:"/super-admin/companies/".concat(t.id,"/edit"),children:(0,n.jsx)(l.z,{variant:"ghost",size:"sm",children:(0,n.jsx)(p.Z,{className:"h-4 w-4"})})}),(0,n.jsx)(l.z,{variant:"ghost",size:"sm",onClick:()=>q(t.id),className:"text-red-600 hover:bg-red-50",children:(0,n.jsx)(f,{className:"h-4 w-4"})})]})}];return(0,n.jsxs)("div",{className:"space-y-6",children:[(0,n.jsxs)("div",{className:"flex items-center justify-between",children:[(0,n.jsxs)("div",{children:[(0,n.jsx)("h1",{className:"text-2xl font-bold",children:"إدارة الشركات"}),(0,n.jsx)("p",{className:"text-muted-foreground",children:"عرض وإدارة جميع الشركات المسجلة"})]}),(0,n.jsx)(r.default,{href:"/super-admin/companies/new",children:(0,n.jsxs)(l.z,{children:[(0,n.jsx)(x.Z,{className:"h-4 w-4"}),"إضافة شركة"]})})]}),(0,n.jsx)(d.Zb,{children:(0,n.jsx)(d.aY,{children:(0,n.jsxs)("div",{className:"flex flex-col md:flex-row gap-4",children:[(0,n.jsx)("div",{className:"flex-1",children:(0,n.jsxs)("div",{className:"relative",children:[(0,n.jsx)(y,{className:"absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"}),(0,n.jsx)("input",{type:"text",placeholder:"بحث بالاسم أو البريد...",value:N,onChange:e=>M(e.target.value),className:"h-10 w-full rounded-lg border border-input bg-background pr-10 pl-4 text-sm focus:outline-none focus:ring-2 focus:ring-ring"})]})}),(0,n.jsxs)("select",{value:w,onChange:e=>z(e.target.value),className:"h-10 rounded-lg border border-input bg-background px-3 text-sm",children:[(0,n.jsx)("option",{value:"",children:"جميع الحالات"}),(0,n.jsx)("option",{value:"active",children:"نشط"}),(0,n.jsx)("option",{value:"trial",children:"تجريبي"}),(0,n.jsx)("option",{value:"suspended",children:"موقوف"}),(0,n.jsx)("option",{value:"expired",children:"منتهي"})]})]})})}),(0,n.jsx)(d.Zb,{children:(0,n.jsxs)(d.aY,{children:[(0,n.jsx)(c.iA,{data:a,columns:E,isLoading:k,emptyMessage:"لا توجد شركات"}),(0,n.jsx)(c.tl,{currentPage:g,totalPages:Math.ceil(Z/10),totalItems:Z,pageSize:10,onPageChange:v})]})})]})}}},function(e){e.O(0,[762,792,46,366,493,971,69,744],function(){return e(e.s=2864)}),_N_E=e.O()}]);